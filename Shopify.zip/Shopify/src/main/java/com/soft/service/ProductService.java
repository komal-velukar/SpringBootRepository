package com.soft.service;





import com.soft.dto.ProductDTO;
import com.soft.entity.Product;

import java.util.List;

public interface ProductService {

    // Get all products
    List<Product> getAll();

    // Save a new product (from DTO) and return the saved entity
    Product save(ProductDTO productDTO);
}